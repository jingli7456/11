library("tm")
library("textstem")
library("NbClust")
library("ggplot2")
library("plotly")
library("wordcloud2")
library("RColorBrewer")
library("reshape2")
library("viridis")
library("factoextra")  # 用于计算聚类的质量
library("topicmodels")
library("ldatuning")
library("doParallel")
library("Matrix")
library("dplyr")
library("text2vec")
library("proxy")   # 用于计算余弦相似性
library("htmlwidgets") 
library("MASS")  # 用于 MDS
library("caret")  # 用于分类任务
library("e1071")  # SVM 分类器
library("cluster")  # 用于计算轮廓系数
library("LDAvis")  
library("tidyr")
library("pheatmap")
library("igraph")
library("slam")
library("ggraph")
library("patchwork") # 用于合并多个图表

#"/Users/yujingli/Desktop/gymnastics/china/2015-2024"
#"/Users/yujingli/Desktop/gymnastics/china/sport development"

setwd("/Users/yujingli/Desktop/gymnastics1")
cname <- file.path("/Users/yujingli/Desktop/gymnastics/china/2015-2024")   
cname   
dir(cname)   # Use this to check to see that your texts have loaded.  

# 创建文本语料库
docs <- Corpus(DirSource(cname))

myStopwords = c(stopwords("en"),"which","be","also","and","our","have","observation","point","realize","start",
                "have","self","old","cause","when","most","among","out","from","find","formation",
                "high","may","after","than","more","between","different","can","to","the","currently",
               "complete","physical","method","content","quality","improve","use","much","change",
                "include","connection","project","type","paper","material","research","analysis","china",
                "year","sport","world","two","competitive","chinese","professional","general","technical",
               "carry","scientific","modern","cultural","broadcast","special","significantly","significant",
               "experimental","rhythmic","")

# 步骤4：创建还原后的停用词列表
myStopwords_lemmatized <- unique(lemmatize_strings(myStopwords))
cat("停用词还原完成。原始数量:", length(myStopwords), "→ 还原后:", length(myStopwords_lemmatized), "\n")

# 2. 词形还原
cat("对停用词列表进行词形还原...\n")
docs <- tm_map(docs, removeWords,(myStopwords_lemmatized))

# . 文本预处理流水线
cat("开始文本预处理...\n")

# 文本预处理
docs <- tm_map(docs, content_transformer(tolower))  # 转换为小写
docs <- tm_map(docs, removePunctuation)  # 移除标点符号
docs <- tm_map(docs, removeNumbers)  # 移除数字

# 2. 先进行词形还原（关键修改）
docs <- tm_map(docs, content_transformer(lemmatize_strings))

# 再次去除空白，因为移除停用词后可能产生新的空白
docs <- tm_map(docs, stripWhitespace)

# 6. 验证结果
cat("预处理完成。检查第一个文档的前300字符:\n")
print(substr(content(docs[1]), 1, 300))

# 再次移除停用词以确保新形式的停用词也被移除
docs <- tm_map(docs, removeWords, myStopwords)

# 构建文本的词频矩阵
dtm <- DocumentTermMatrix(docs)

# 将文档-词矩阵转换为普通矩阵形式
dtm_matrix <- as.matrix(dtm)

# 提取保留单词的频率
word_freq <- colSums(as.matrix(dtm))  # 假设dtm是文档-词矩阵

# 创建词频数据框
word_freq <- data.frame(
  word = names(word_freq),
  freq = as.numeric(word_freq)
)

# 使用更丰富的颜色调色板，避免黑色
color_palette <- colorRampPalette(brewer.pal(8, "Set2"))(100)

# 绘制椭圆形词云图
set.seed(1234) # 为了结果可重复
wordcloud2(
  data = word_freq,
  shape = 'ellipse',
  size = 1,
  color = color_palette
)

# 设置随机种子
set.seed(1234)

# 设置参数
num_iterations <- 1000
num_burnin <- 500

# 计算困惑度的函数
compute_perplexity_gibbs <- function(num_topics) {
  lda_model <- LDA(dtm, k = num_topics, method = "Gibbs",
                   control = list(seed = 1234, iter = num_iterations, burnin = num_burnin))
  perplexity(lda_model, newdata = dtm)  # 或者直接 perplexity(lda_model)
}

# 确保 ldatuning 包的可用性
if (!requireNamespace("ldatuning", quietly = TRUE)) {
  install.packages("ldatuning")
}
library(ldatuning)

# 第一步：计算2到20之间的主题一致性
results_initial <- FindTopicsNumber(
  dtm,
  topics = seq(2, 10, by = 1),
  metrics = c("CaoJuan2009", "Arun2010", "Deveaud2014"),
  method = "Gibbs",
  control = list(seed = 1234, iter = num_iterations, burnin = num_burnin),
  mc.cores = parallel::detectCores() - 1
)

library(parallel)
cl <- makeCluster(detectCores() - 1)

# 在计算完成后停止集群
stopCluster(cl)

if (!requireNamespace("slam", quietly = TRUE)) {
  install.packages("slam")
}

# 检查空行
row_sums <- slam::row_sums(dtm)
non_empty_rows <- row_sums > 0
selected_dtm <- dtm[non_empty_rows, ]

# 检查 results_initial 中是否有缺失值
print("Results contain NA values:")
print(any(is.na(results_initial)))

# 如果存在缺失值，打印具体位置
if (any(is.na(results_initial))) {
  print("NA values found at:")
  print(which(is.na(results_initial), arr.ind = TRUE))
}

# 移除含有缺失值的行
results_initial <- na.omit(results_initial)

# 检查 results_initial 内容并打印
print("Results after removing NA values:")
print(results_initial)

# 确保 results_initial 不是空的
if (nrow(results_initial) == 0) {
  stop("No valid results found. Please check the input data and parameters.")
}

# 绘制一致性图
FindTopicsNumber_plot(results_initial)

# 打印 results_initial 以检查其内容
print(results_initial)

# 定义评分计算函数
calculate_comprehensive_score <- function(metrics, weights) {
  # 标准化指标：将所有指标转换为[0,1]范围且值越大越好
  standardized_metrics <- apply(metrics, 2, function(x) {
    if (all(is.na(x))) return(rep(NA, length(x)))
    (x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
  })
  
  # 计算加权综合评分
  score <- rowSums(t(t(standardized_metrics) * weights), na.rm = TRUE)
  return(score)
}

# 定义网格搜索范围
weight_combinations <- expand.grid(
  weight1 = seq(0.1, 0.8, by = 0.1),  # CaoJuan2009权重
  weight2 = seq(0.1, 0.8, by = 0.1)   # Arun2010权重
)
weight_combinations$weight3 <- 1 - weight_combinations$weight1 - weight_combinations$weight2  # Deveaud2014权重
weight_combinations <- weight_combinations[weight_combinations$weight3 >= 0, ]  # 过滤无效组合

# 计算有效组合数量
num_combinations <- nrow(weight_combinations)
print(num_combinations)

# 初始化最佳评分和权重
best_score <- -Inf
best_weights <- NULL

# 计算综合评分并选择最佳权重
for (i in 1:nrow(weight_combinations)) {
  weights <- c(weight_combinations[i, 1], weight_combinations[i, 2], weight_combinations[i, 3])
  
  # 计算当前权重下的综合评分
  scores <- calculate_comprehensive_score(
    results_initial[, c("CaoJuan2009", "Arun2010", "Deveaud2014")], 
    weights
  )
  
  # 计算平均分（避免异常值影响）
  avg_score <- mean(scores, na.rm = TRUE)
  
  # 更新最佳权重
  if (avg_score > best_score) {
    best_score <- avg_score
    best_weights <- weights
  }
}

# 打印最佳权重组合
print(best_weights)

# 使用最佳权重计算最终的综合评分
score_weights <- best_weights
coherence_metrics <- results_initial[, c("CaoJuan2009", "Arun2010", "Deveaud2014")]

# 标准化并计算综合评分
standardized_coherence <- apply(coherence_metrics, 2, function(x) {
  (x - min(x)) / (max(x) - min(x))
})
comprehensive_scores <- rowSums(t(t(standardized_coherence) * score_weights))

# 检查综合评分
print(comprehensive_scores)

# 找到综合评分最高的主题数（关键修复）
# 创建主题数映射：results_initial中的行对应主题数2到30
topic_numbers <- 2:(nrow(results_initial) + 1)  # 主题数范围

# 找到最高分对应的索引
best_index <- which.max(comprehensive_scores)

# 获取实际主题数
best_num_topics <- topic_numbers[best_index]

# 输出最佳主题数
cat("最佳主题数为:", best_num_topics, "\n")
cat("对应综合评分为:", comprehensive_scores[best_index], "\n")

# 可视化结果对比
plot(topic_numbers, comprehensive_scores, type = "b", 
     xlab = "主题数量", ylab = "综合评分",
     main = "综合评分 vs 主题数量")
points(best_num_topics, comprehensive_scores[best_index], 
       col = "red", pch = 19, cex = 1.5)
text(best_num_topics, comprehensive_scores[best_index], 
     labels = paste("最佳:", best_num_topics), pos = 3, col = "red")

# 确保必要包已加载
library(topicmodels)
library(Matrix)

# Jensen–Shannon 距离的内置实现（不依赖 philentropy）
js_distance_simple <- function(p, q) {
  # p, q: 数值向量，且均为概率分布（和为 1），长度相同
  m <- 0.5 * (p + q)
  kl_p_m <- ifelse(p > 0, p * log(p / m), 0)
  kl_q_m <- ifelse(q > 0, q * log(q / m), 0)
  0.5 * (sum(kl_p_m, na.rm = TRUE) + sum(kl_q_m, na.rm = TRUE))
}

# 评估单个 K 的分离度（不依赖 philentropy）
evaluate_K_separation_no_phil <- function(K, dtm, top_n = 20, seed = 1234, iter = 1000, burnin = 500) {
  set.seed(seed)
  lda_model <- LDA(dtm, k = K, method = "Gibbs",
                   control = list(seed = seed, iter = iter, burnin = burnin))
  phi <- posterior(lda_model)$terms  # vocab x K，topic 词分布
  
  # 归一化每一列（确保概率分布）
  phi_norm <- phi
  phi_norm <- sweep(phi_norm, 2, colSums(phi_norm), FUN = "/")
  
  vocab <- rownames(phi_norm)
  # 1) 计算 Mean JS：主题之间分布的距离
  n <- K
  js_vals <- c()
  if (n >= 2) {
    for (i in 1:(n-1)) {
      for (j in (i+1):n) {
        p_i <- as.numeric(phi_norm[, i])
        p_j <- as.numeric(phi_norm[, j])
        js_vals <- c(js_vals, js_distance_simple(p_i, p_j))
      }
    }
  }
  mean_js <- if (length(js_vals) > 0) mean(js_vals, na.rm = TRUE) else NA
  
  # 2) Top-N 词的 Jaccard 距离
  top_words <- lapply(1:K, function(k) {
    ord <- order(phi_norm[, k], decreasing = TRUE)
    vocab[ord[1:min(top_n, length(ord))]]
  })
  
  jaccard_vals <- c()
  if (K >= 2) {
    for (i in 1:(K-1)) {
      for (j in (i+1):K) {
        a <- top_words[[i]]
        b <- top_words[[j]]
        sim <- length(intersect(a, b)) / length(union(a, b))
        jaccard_vals <- c(jaccard_vals, 1 - sim)  # 距离形式
      }
    }
  }
  mean_jaccard <- if (length(jaccard_vals) > 0) mean(jaccard_vals, na.rm = TRUE) else NA
  
  data.frame(K = K, mean_js = mean_js, mean_jaccard = mean_jaccard, stringsAsFactors = FALSE)
}

# 3) 对候选 K 计算分离度
candidate_K <- c(9, 12, 22, 32, 42)
sep_results <- do.call(rbind, lapply(candidate_K, function(K) {
  evaluate_K_separation_no_phil(K, dtm)
}))

print("候选 K 的分离度结果：")
print(sep_results)

# 4) 基于分离度选取最佳 K
# 1) 按 mean_js 最大的 K
best_by_js <- sep_results$K[which.max(sep_results$mean_js)]
cat("基于分离度（mean_js 最大）推荐的最佳主题数：", best_by_js, "\n")

# 2) 综合对比：将 mean_js 和 mean_jaccard 归一化后加权
range_js <- range(sep_results$mean_js, na.rm = TRUE)
range_jacc <- range(sep_results$mean_jaccard, na.rm = TRUE)

norm_js <- (sep_results$mean_js - range_js[1]) / (range_js[2] - range_js[1])
# mean_jaccard 越小越好，做反向归一化
norm_jaccard <- 1 - (sep_results$mean_jaccard - range_jacc[1]) / (range_jacc[2] - range_jacc[1])

# 5) 基于指标质量的动态权重计算函数
calculate_dynamic_weights <- function(sep_results) {
  # 评估指标的质量（变化范围）
  js_range <- diff(range(sep_results$mean_js, na.rm = TRUE))
  jaccard_range <- diff(range(sep_results$mean_jaccard, na.rm = TRUE))
  
  # 处理可能为0的范围
  if (js_range == 0 && jaccard_range == 0) {
    # 如果两个指标都没有变化，使用等权重
    w_js <- 0.5
    w_jaccard <- 0.5
  } else if (js_range == 0) {
    # 如果只有JS距离没有变化，主要依赖Jaccard
    w_js <- 0.1
    w_jaccard <- 0.9
  } else if (jaccard_range == 0) {
    # 如果只有Jaccard没有变化，主要依赖JS距离
    w_js <- 0.9
    w_jaccard <- 0.1
  } else {
    # 正常情况：根据指标变化范围分配权重
    total_range <- js_range + jaccard_range
    w_js <- js_range / total_range
    w_jaccard <- jaccard_range / total_range
  }
  
  # 确保权重不为0且和为1
  w_js <- max(w_js, 0.1)
  w_jaccard <- max(w_jaccard, 0.1)
  total_w <- w_js + w_jaccard
  w_js <- w_js / total_w
  w_jaccard <- w_jaccard / total_w
  
  return(list(w_js = w_js, w_jaccard = w_jaccard))
}

# 6) 应用动态权重计算综合评分
# 计算动态权重
dynamic_weights <- calculate_dynamic_weights(sep_results)
w_js <- dynamic_weights$w_js
w_jaccard <- dynamic_weights$w_jaccard

cat("基于指标质量计算的动态权重:\n")
cat("JS距离权重:", round(w_js, 3), "\n")
cat("Jaccard距离权重:", round(w_jaccard, 3), "\n")

# 计算综合评分
combined_score <- w_js * norm_js + w_jaccard * norm_jaccard
sep_results$combined_score <- combined_score

# 找到综合评分最高的K
best_by_combined <- sep_results$K[which.max(sep_results$combined_score)]
cat("基于动态权重综合评分推荐的最佳主题数:", best_by_combined, "\n")

# 7) 可视化结果对比
cat("\n=== 各K值的评分对比 ===\n")
result_comparison <- sep_results[, c("K", "mean_js", "mean_jaccard", "combined_score")]
result_comparison$norm_js <- norm_js
result_comparison$norm_jaccard <- norm_jaccard
result_comparison$w_js <- w_js
result_comparison$w_jaccard <- w_jaccard
print(result_comparison)

# 8) 敏感性分析（测试不同权重下的稳定性）
sensitivity_analysis <- function(sep_results, weight_combinations = NULL) {
  if (is.null(weight_combinations)) {
    # 生成权重组合
    weight_combinations <- expand.grid(
      w_js = seq(0.1, 0.9, by = 0.2),
      w_jaccard = seq(0.1, 0.9, by = 0.2)
    )
    weight_combinations <- weight_combinations[
      abs(weight_combinations$w_js + weight_combinations$w_jaccard - 1) < 0.01, 
    ]
  }
  
  results <- data.frame()
  for (i in 1:nrow(weight_combinations)) {
    w_js <- weight_combinations$w_js[i]
    w_jaccard <- weight_combinations$w_jaccard[i]
    
    # 计算综合评分
    combined_score <- w_js * norm_js + w_jaccard * norm_jaccard
    best_k <- sep_results$K[which.max(combined_score)]
    
    results <- rbind(results, data.frame(
      w_js = w_js,
      w_jaccard = w_jaccard,
      best_k = best_k,
      max_score = max(combined_score)
    ))
  }
  
  return(results)
}

# 执行敏感性分析
sens_results <- sensitivity_analysis(sep_results)
cat("\n=== 敏感性分析结果 ===\n")
cat("不同权重下推荐的最佳K值分布:\n")
print(table(sens_results$best_k))

# 选择最稳定的K值
if (length(unique(sens_results$best_k)) == 1) {
  best_k_final <- unique(sens_results$best_k)
  cat("所有权重组合均推荐相同K值:", best_k_final, "\n")
} else {
  best_k_final <- as.numeric(names(which.max(table(sens_results$best_k))))
  cat("最稳定的K值（出现频率最高）:", best_k_final, "\n")
  cat("出现频率:", max(table(sens_results$best_k)) / nrow(sens_results) * 100, "%\n")
}

# 9) 最终推荐
cat("\n=== 最终推荐 ===\n")
cat("基于JS距离最大: K =", best_by_js, "\n")
cat("基于动态权重综合评分: K =", best_by_combined, "\n")
cat("基于敏感性分析最稳定: K =", best_k_final, "\n")

# 综合所有方法选择最终K值
final_recommendation <- if (best_by_js == best_by_combined && best_by_combined == best_k_final) {
  best_by_js
} else {
  # 如果方法间有分歧，选择敏感性分析结果
  best_k_final
}

cat("最终推荐的主题数量: K =", final_recommendation, "\n")

# 10) 可视化展示
library(ggplot2)
library(reshape2)

# 确保 plot_data 包含所有需要的列
plot_data <- sep_results
plot_data$K <- factor(plot_data$K, levels = candidate_K)

# 添加归一化指标和综合评分列到 plot_data
plot_data$norm_js <- norm_js
plot_data$norm_jaccard <- norm_jaccard
plot_data$combined_score <- combined_score

# 创建标准化指标对比图（修复警告）
melted_data <- melt(plot_data, id.vars = "K", 
                    measure.vars = c("norm_js", "norm_jaccard", "combined_score"))

# 使用 linewidth 替代 size（修复警告）
p <- ggplot(melted_data, aes(x = K, y = value, color = variable, group = variable)) +
  geom_line(linewidth = 1) +  # 使用 linewidth 替代 size
  geom_point(size = 2) +
  labs(title = "Comparison of Standardized Metrics Across Different K Values",
       x = "Number of Topics (K)",
       y = "Normalized Score",
       color = "Metric") +
  scale_color_manual(
    values = c("norm_js" = "blue", "norm_jaccard" = "red", "combined_score" = "green"),
    labels = c("norm_js" = "JS Distance", "norm_jaccard" = "Jaccard Distance", "combined_score" = "combined score")
  ) +
  theme_minimal()

print(p)

# 添加最终推荐标记
p_final <- p + 
  geom_vline(xintercept = which(levels(plot_data$K) == as.character(final_recommendation)), 
             linetype = "dashed", color = "black", linewidth = 1) +
  annotate("text", 
           x = which(levels(plot_data$K) == as.character(final_recommendation)), 
           y = max(melted_data$value, na.rm = TRUE) * 0.9, 
           label = paste("OptimalK =", final_recommendation), 
           hjust = -0.1, color = "black", fontface = "bold")

print(p_final)

# 保存图表（可选）
# 保存符合《科学报告》期刊要求的高清图表
ggsave(
  filename = "optimal_k_selection_analysis.png",  # 图片文件名
  plot     = p_final,                              # 您的图表对象
  device   = "png",
  path     = "/Users/yujingli/Desktop/gymnastics1", # **修改为您的绝对路径**
  width    = 3.5,                                  # 宽度3.5英寸
  height   = 2.1,
  units    = "in",
  dpi      = 1200,
  bg       = "white"
)
# ========== 最佳主题数确定代码 ==========

cat("\n=== 最佳主题数确定与分析 ===\n")

# 1. 显示所有候选K值的详细指标
cat("所有候选K值的详细指标:\n")
detailed_results <- data.frame(
  K = candidate_K,
  JS距离 = round(sep_results$mean_js, 4),
  Jaccard距离 = round(sep_results$mean_jaccard, 4),
  标准化JS距离 = round(norm_js, 4),
  标准化Jaccard距离 = round(norm_jaccard, 4),
  综合评分 = round(combined_score, 4),
  排名 = rank(-combined_score)
)

print(detailed_results)

# 2. 确定最佳主题数（基于综合评分最高）
best_k <- candidate_K[which.max(combined_score)]
cat("\n基于综合评分最高的最佳主题数: K =", best_k, "\n")
cat("综合评分:", round(max(combined_score), 4), "\n")

# 3. 验证选择的合理性
cat("\n=== 选择验证 ===\n")
cat("最佳K值在各指标中的排名:\n")
best_row <- detailed_results[detailed_results$K == best_k, ]
cat("JS距离排名:", rank(-detailed_results$JS距离)[detailed_results$K == best_k], "/", nrow(detailed_results), "\n")
cat("Jaccard距离排名:", rank(detailed_results$Jaccard距离)[detailed_results$K == best_k], "/", nrow(detailed_results), "\n")
cat("综合评分排名:", rank(-detailed_results$综合评分)[detailed_results$K == best_k], "/", nrow(detailed_results), "\n")

# 4. 使用最佳K值运行LDA模型
cat("\n=== 运行LDA主题建模 ===\n")
cat("使用最佳主题数 K =", best_k, "运行LDA模型...\n")

# 打印最佳主题数的主题关键词
# 使用最终建议的最佳主题数
lda_best <- LDA(selected_dtm, k = best_k, method = "Gibbs",
                control = list(seed = 1234, iter = num_iterations, burnin = num_burnin))
print(terms(lda_best, 10))

# 提取主题-词汇分布矩阵
topic_word_matrix <- posterior(lda_best)$terms

# 打印主题-词汇分布矩阵的部分内容
print("Topic-Word Matrix:")
print(head(topic_word_matrix))

# 获取每个主题的单词分布
beta <- exp(lda_best@beta)  # 转换为概率

# 计算每个主题的强度（前十个权重单词的和）
topic_strength <- numeric(nrow(beta))  # 初始化一个向量来存储每个主题的强度

for (i in 1:nrow(beta)) {
  # 获取当前主题的前十个权重单词的权重
  top_words <- sort(beta[i, ], decreasing = TRUE)[1:10]
  # 计算这些单词的权重和
  topic_strength[i] <- sum(top_words)
}

# 创建一个数据框来存储主题强度
topic_intensity_df <- data.frame(Topic = 1:nrow(beta), Intensity = topic_strength)

# 输出主题强度结果
print(topic_intensity_df)

# 假设 topic_intensity 是一个数据框，包含 Topic 和 Intensity 列
# 计算强度均值
mean_intensity <- mean(topic_intensity_df$Intensity, na.rm = TRUE)

# 确定点的颜色
topic_intensity_df$PointColor <- ifelse(topic_intensity_df$Intensity < mean_intensity, "red", "yellow")

# 可视化强度结果（折线图）
library(ggplot2)

ggplot(topic_intensity_df, aes(x = Topic, y = Intensity, group = 1)) +
  geom_line(color = "blue", size = 0.5) +  # 蓝色折线
  geom_point(aes(color = PointColor), size = 3) +  # 根据强度设置点的颜色
  scale_color_identity() +  # 直接使用颜色
  geom_hline(yintercept = mean_intensity, color = "green", linetype = "dashed", size = 1) +  # 绿色均值线
  annotate("text", x = max(topic_intensity_df$Topic), y = mean_intensity, label = paste("Mean Threshold:", round(mean_intensity, 2)), 
           vjust = -0.5, hjust = 1.1, color = "green", size = 5, fontface = "bold") +  # 均值标签
  labs(x = "Topic", y = "Intensity", title = "Topic Intensity with Mean Threshold") +
  theme_minimal(base_size = 16) +  # 使用更大的字体
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 20, color = "#333333"),  # 标题
    axis.title.x = element_text(face = "bold", size = 14, color = "#333333"),  # X轴标题
    axis.title.y = element_text(face = "bold", size = 14, color = "#333333"),  # Y轴标题
    axis.text = element_text(size = 12, color = "#555555"),  # 坐标轴文本
    panel.grid.major = element_line(color = "grey90"),  # 主网格线颜色
    panel.grid.minor = element_blank(),  # 不显示次网格线
    plot.background = element_rect(fill = "white"),  # 背景颜色
    panel.background = element_rect(fill = "white")  # 面板背景颜色
  )

# 计算主题之间的相似性矩阵（余弦相似性）
topic_sim_matrix <- function(lda_model) {
  beta <- exp(lda_model@beta)  # 转换为概率
  sim_matrix <- proxy::simil(beta, method = "cosine")
  return(as.matrix(sim_matrix))
}

# 打印最佳主题数的主题关键词
# 使用最终建议的最佳主题数 final_recommendation
lda_best <- LDA(selected_dtm, k = best_k, method = "Gibbs",
                control = list(seed = 1234, iter = num_iterations, burnin = num_burnin))
print(terms(lda_best, 10))

# 计算相似性矩阵
sim_matrix <- topic_sim_matrix(lda_best)

# 1) 假设你已经有 sim_matrix
# 2) 清洗 sim_matrix，确保无 NA、自相似为 1、对称
diag(sim_matrix) <- 1
sim_matrix[is.na(sim_matrix)] <- 0
sim_matrix <- (sim_matrix + t(sim_matrix)) / 2
diag(sim_matrix) <- 1

# 打印相似性矩阵
print(sim_matrix)

# 进行层次聚类
dist_matrix <- as.dist(1 - sim_matrix)  # 将相似性转换为距离
hc <- hclust(dist_matrix, method = "ward.D2")

# ==================== 在这里插入辅助函数 ====================
# 首先定义辅助函数
find_height_for_k <- function(hc, k) {
  # 层次聚类的高度信息
  heights <- hc$height
  n <- length(heights) + 1  # 初始样本数

  # 当形成k个聚类时对应的合并高度
  # 我们需要找到第(n-k)次合并的高度
  if (k == 1) return(max(heights) + 0.1)  # 如果k=1，设为最大高度+偏移
  if (k == n) return(0)  # 如果k=n，设为0
  
  index <- n - k
  if (index < 1) index <- 1
  if (index > length(heights)) index <- length(heights)
  
  return(heights[index])
}

# 然后定义肘部法则函数（修正版）
elbow_method <- function(hc, dist_matrix, max_k = 10) {
  k_range <- 1:min(max_k, nrow(hc$merge) + 1)
  within_ss <- numeric(length(k_range))
  
  for (i in seq_along(k_range)) {
    k <- k_range[i]
    clusters <- cutree(hc, k = k)
    
    # 计算类内离差平方和
    if (k == 1) {
      within_ss[i] <- sum(dist_matrix^2)
    } else {
      # 计算每个聚类的类内距离和
      total_within_ss <- 0
      for (j in 1:k) {
        cluster_points <- which(clusters == j)
        if (length(cluster_points) > 1) {
          cluster_dist <- as.matrix(dist_matrix)[cluster_points, cluster_points]
          total_within_ss <- total_within_ss + sum(cluster_dist^2) / (2 * length(cluster_points))
        }
      }
      within_ss[i] <- total_within_ss
    }
  }
  
  # 计算相邻k值的差异（寻找拐点）
  differences <- diff(within_ss)
  if (length(differences) > 1) {
    relative_diff <- differences[-1] / differences[-length(differences)]
    # 寻找变化率最大的点（肘部）
    if (length(relative_diff) > 0) {
      elbow_point <- which.min(relative_diff) + 2  # +2 因为从k=2开始比较
    } else {
      elbow_point <- 2
    }
  } else {
    elbow_point <- 2
  }
  
  # 确保elbow_point在合理范围内
  elbow_point <- min(max(elbow_point, 2), length(k_range))
  optimal_height <- find_height_for_k(hc, elbow_point)
  
  return(list(elbow_k = elbow_point,
              optimal_height = optimal_height,
              within_ss = data.frame(k = k_range, within_ss = within_ss)))
}
# ==================== 辅助函数定义结束 ====================

# ==================== 在这里调用函数 ====================
# 现在实际调用函数（这是缺失的关键步骤！）
elbow_result <- elbow_method(hc, dist_matrix, max_k = 10)

# 然后使用结果
cat("=== 肘部法则结果 ===\n")
cat("最优聚类数 k =", elbow_result$elbow_k, "\n")
cat("建议截断高度 =", elbow_result$optimal_height, "\n\n")

# 绘制肘部法则图
plot(elbow_result$within_ss$k, elbow_result$within_ss$within_ss,
     type = "b", xlab = "聚类数 k", ylab = "类内离差平方和",
     main = "肘部法则")

# 标记肘部点
points(elbow_result$elbow_k, 
       elbow_result$within_ss$within_ss[elbow_result$within_ss$k == elbow_result$elbow_k],
       col = "red", pch = 19, cex = 2)
text(elbow_result$elbow_k, 
     elbow_result$within_ss$within_ss[elbow_result$within_ss$k == elbow_result$elbow_k],
     labels = paste("肘部点 k =", elbow_result$elbow_k), 
     pos = 3, col = "red")
# ==================== 函数调用结束 ====================

# 现有代码继续
# 选择最终截断高度（以肘部法则为准）
final_cut_height <- elbow_result$optimal_height
final_clusters <- cutree(hc, h = final_cut_height)

cat("\n=== 最终选择 ===\n")
cat("选择的截断高度 =", final_cut_height, "\n")
cat("聚类结果:\n")
print(final_clusters)

# 绘制树状图
plot(hc, main = "Topic Hierarchical Clustering Dendrogram", xlab = "Topics", ylab = "Height")

# 设置截断高度
cut_height <- 0.9151592   # 你想要的截断高度
abline(h = cut_height, col = "red", lty = 2)  # 添加水平线

# 根据截断高度获取聚类
clusters <- cutree(hc, h = cut_height)

# 打印聚类结果
print(clusters)

library(dendextend)

# 打印聚类数量
num_clusters <- length(unique(clusters))
cat("Number of clusters:", num_clusters, "\n")

# 将相似性矩阵转换为图对象
sim_graph <- graph_from_adjacency_matrix(sim_matrix, mode = "undirected", weighted = TRUE)

# 设置权重阈值
threshold <- 0.01  # 设定一个阈值，例如 0.01

# 手动定义颜色
cluster_colors <- c("red", "blue", "green", "purple", "orange", "cyan")  # 根据聚类数量自行调整

ggraph(sim_graph, layout = "fr") + 
  geom_edge_link(aes(edge_alpha = weight, color = weight), show.legend = TRUE) +  # 根据权重调整边的颜色
  geom_node_point(aes(color = as.factor(clusters), size = degree(sim_graph)), show.legend = TRUE) +  # 转换 clusters 为因子
  geom_node_text(aes(label = name), repel = TRUE) + 
  theme_void() +
  labs(title = "Topic Similarity Network Graph") +
  scale_color_manual(values = cluster_colors) +  # 使用为聚类分配的颜色
  scale_edge_color_gradient(low = "blue", high = "red") +  # 边的颜色渐变
  theme(legend.position = "bottom")

# 1. 绘制树状图（转换为ggplot对象）
# 创建颜色向量，与网络图保持一致
dend <- as.dendrogram(hc)
colors_dend <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#A65628")
dend_colored <- color_branches(dend, h = cut_height, col = colors_dend[1:num_clusters])

# 将树状图转换为ggplot对象
p_dendro <- ggplot(dend_colored, theme = theme_minimal()) +
  labs(title = "Topic Hierarchical Clustering Dendrogram",
       x = "Topics", y = "Height") +
  geom_hline(yintercept = cut_height, color = "red", linetype = "dashed", linewidth = 0.8) +
  annotate("text", x = Inf, y = cut_height, 
           label = paste("Cut height:", round(cut_height, 4)),
           hjust = 1.1, vjust = -0.5, color = "red", size = 3, fontface = "bold") +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 11, color = "#333333"),
    axis.title.x = element_text(face = "bold", size = 9, color = "#333333"),
    axis.title.y = element_text(face = "bold", size = 9, color = "#333333"),
    axis.text = element_text(size = 8, color = "#555555"),
    panel.grid.major = element_line(color = "grey90"),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = "white"),
    panel.background = element_rect(fill = "white")
  )

# 2. 绘制主题相似性网络图
# 设置权重阈值
threshold <- 0.01  # 设定一个阈值，例如 0.01

# 手动定义颜色（与树状图保持一致）
cluster_colors <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#A65628")

# 将相似性矩阵转换为图对象
sim_graph <- graph_from_adjacency_matrix(sim_matrix, mode = "undirected", weighted = TRUE)

# 创建网络图
p_network <- ggraph(sim_graph, layout = "fr") + 
  geom_edge_link(aes(edge_alpha = weight, edge_width = weight), 
                 color = "grey60", 
                 show.legend = TRUE) +
  geom_node_point(aes(color = as.factor(clusters), 
                      size = degree(sim_graph)),
                  alpha = 0.8,
                  show.legend = TRUE) +  # 使用树状图得到的clusters
  geom_node_text(aes(label = name), 
                 repel = TRUE,
                 size = 2.5,  # 高DPI下调整为小号字体
                 point.padding = unit(0.2, "lines")) + 
  theme_void() +
  labs(title = "Topic Similarity Network Graph",
       color = "Cluster",
       size = "Degree") +
  scale_color_manual(values = cluster_colors[1:num_clusters]) +  # 使用树状图的颜色
  scale_edge_alpha_continuous(range = c(0.1, 0.8), 
                              breaks = c(0.1, 0.3, 0.5, 0.7)) +
  scale_edge_width_continuous(range = c(0.2, 1.5),
                              breaks = c(0.2, 0.8, 1.4)) +
  scale_size_continuous(range = c(2, 6),
                        breaks = c(2, 4, 6)) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 11, 
                              color = "#333333", margin = margin(b = 10)),
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.title = element_text(size = 8, face = "bold"),
    legend.text = element_text(size = 7),
    legend.key.size = unit(0.3, "cm"),
    legend.spacing = unit(0.2, "cm")
  ) +
  guides(
    color = guide_legend(nrow = 1, override.aes = list(size = 4)),
    size = guide_legend(nrow = 1),
    edge_alpha = guide_legend(title = "Edge Weight", nrow = 1),
    edge_width = guide_legend(title = "Edge Weight", nrow = 1)
  )

# 3. 打印聚类信息
cat("聚类数量:", num_clusters, "\n")
cat("聚类分配:\n")
print(clusters)

# 4. 使用patchwork组合两个图形
combined_plot <- p_dendro + p_network + 
  plot_layout(ncol = 2, widths = c(1, 1.2)) +  # 水平排列，右侧稍宽
  plot_annotation(tag_levels = 'A') & 
  theme(plot.tag = element_text(face = "bold", size = 12))

# 5. 显示组合图
print(combined_plot)

# 6. 保存符合期刊要求的高质量图像
save_path <- "/Users/yujingli/Desktop/gymnastics1"

# PDF矢量图（首选，无限清晰）
ggsave(
  filename = file.path(save_path, "topic_clustering_network_combined.pdf"),
  plot = combined_plot,
  device = cairo_pdf,
  width = 12,    # 通栏宽度（英寸），适合两个子图并排
  height = 6,    # 高度（英寸）
  units = "in"
)

# 高分辨率PNG（备用）
ggsave(
  filename = file.path(save_path, "topic_clustering_network_combined.png"),
  plot = combined_plot,
  device = "png",
  width = 12,
  height = 6,
  units = "in",
  dpi = 1200,    # ≥1000 DPI，满足期刊要求
  bg = "white"
)

cat("\n图表已成功保存至：\n")
cat("1. PDF矢量图：", file.path(save_path, "topic_clustering_network_combined.pdf"), "\n")
cat("2. 高清PNG：", file.path(save_path, "topic_clustering_network_combined.png"), "\n")
cat("\n请检查上述文件夹。\n")

# 假设 doc_topic_matrix 是文档-主题分布矩阵
# 假设 clusters 是从层次聚类中得到的主题聚类结果

# 获取每个文档的主题分布
doc_topic_matrix <- posterior(lda_best)$topics

# 为每个文档分配到其主题分布中概率最大的主题
assigned_topics <- apply(doc_topic_matrix, 1, which.max)

# 创建文档-主题数据框
document_list <- rownames(selected_dtm)  # 假设文档名在文档矩阵的行名中
doc_topic_df <- data.frame(Document = document_list, Assigned_Topic = assigned_topics)

# 将每个文档分配到合并后的主题
doc_topic_df$Cluster <- clusters[doc_topic_df$Assigned_Topic]

# 打印文档-主题数据框
print(doc_topic_df)

# 1. 模拟两位独立专家的标注过程
cat("=== 主题标注过程 ===\n")

# 获取每个主题的关键词用于专家标注
topic_keywords <- terms(lda_best, 10)  # 每个主题取前10个关键词

# 使用您已经定义好的专家标注（删除重新生成标签的部分）
expertA_labels <- c("Skill Development and Training of Juvenile Gymnastics","Construction of the Training System for Gymnastics Reserve Talents",
                    "Research on Competitive Gymnastics Techniques and Scoring Rules","Reform and Promotion of School Gymnastics Education",
                    "Competitive Landscape of Olympic Gymnastics Events","Training and Evaluation of Core Physical Fitness Elements",
                    "Research on the Characteristics and Aesthetics of Rhythmic Gymnastics","Construction of Gymnastics Evaluation System",
                    "Application of Information Science and Technology in the Field of Gymnastics","Biomechanical Analysis of Gymnastics Technical Movements",
                    "Difficulty Levels and Progressive Training of Women's Gymnastics Movements","School Gymnastics Education and Curriculum Design")

expertB_labels <- c( "Juvenile Gymnastics Skill Development and Training Programs",  
                     "Construction of the Training System for Gymnastics Reserve Talents",                   
                     "Research on Competitive Gymnastics Techniques and Scoring Rules",    
                     "Innovation and Dissemination of School Gymnastics Education",                 
                     "Competitive Landscape of Olympic Gymnastics Events",       
                     "Training and Evaluation of Core Physical Fitness Elements",         
                     "Characteristics and Aesthetic Evaluation of Artistic Gymnastics Performances",                   
                     "Construction of Gymnastics Evaluation System",            
                     "Applications of Data Analytics and Digital Technology in Gymnastics",         
                     "Biomechanical Analysis of Gymnastics Technical Movements",         
                     "Progression of Technical Difficulty in Women's Competitive Gymnastics",           
                     "School Gymnastics Education and Curriculum Design")

cat("专家标注完成！正在展示标注结果...\n")

# 直接展示专家标注结果，不重新生成
for(topic_id in 1:best_k) {
  keywords <- paste(topic_keywords[, topic_id], collapse = ", ")
  
  cat(sprintf("主题 %d: %s\n", topic_id, keywords))
  cat(sprintf("  专家A: %s\n", expertA_labels[topic_id]))
  cat(sprintf("  专家B: %s\n", expertB_labels[topic_id]))
  
  # 检查是否有分歧
  if(expertA_labels[topic_id] != expertB_labels[topic_id]) {
    cat(sprintf("  ⚠️ 专家存在分歧\n"))
  } else {
    cat(sprintf("  ✅ 专家意见一致\n"))
  }
  cat("---\n")
}

# 2. 计算评分者间一致性统计（Cohen's kappa）
cat("=== 评分者一致性分析 ===\n")

# 安装并加载irr包（如果未安装）
if(!require(irr)) {
  install.packages("irr")
  library(irr)
}

# 准备数据计算Kappa
rating_data <- data.frame(
  ExpertA = expertA_labels,
  ExpertB = expertB_labels
)

# 计算Cohen's Kappa
kappa_result <- kappa2(rating_data)

# 详细输出Kappa结果
cat(sprintf("Cohen's Kappa 系数 = %.3f\n", kappa_result$value))
cat(sprintf("标准误 = %.3f\n", kappa_result$subject.n))
cat(sprintf("Z统计量 = %.3f\n", kappa_result$statistic))
cat(sprintf("p-value = %.4f\n", kappa_result$p.value))

# Kappa值解释
interpret_kappa <- function(kappa) {
  if(kappa < 0) return("差的一致性")
  if(kappa <= 0.2) return("轻微的一致性")
  if(kappa <= 0.4) return("一般的一致性") 
  if(kappa <= 0.6) return("中等的一致性")
  if(kappa <= 0.8) return("高度的一致性")
  return("几乎完全一致")
}

# 置信区间计算
kappa_ci <- function(kappa, se, conf.level = 0.95) {
  z <- qnorm(1 - (1 - conf.level)/2)
  lower <- kappa - z * se
  upper <- kappa + z * se
  return(c(lower, upper))
}

# 计算置信区间（简化版）
se_kappa <- sqrt((kappa_result$value * (1 - kappa_result$value)) / nrow(rating_data))
ci <- kappa_ci(kappa_result$value, se_kappa)

cat(sprintf("95%% 置信区间: [%.3f, %.3f]\n", ci[1], ci[2]))
cat(sprintf("一致性水平: %s\n", interpret_kappa(kappa_result$value)))

# 统计显著性判断
if(kappa_result$p.value < 0.05) {
  cat("统计显著性: ✅ p < 0.05，结果具有统计显著性\n")
} else {
  cat("统计显著性: ❌ p >= 0.05，结果不具有统计显著性\n")
}

# 3. 详细的分歧分析
cat("\n=== 专家分歧详细分析 ===\n")
total_topics <- best_k
agreed_topics <- sum(expertA_labels == expertB_labels)
disagreed_topics <- sum(expertA_labels != expertB_labels)

cat(sprintf("总主题数: %d\n", total_topics))
cat(sprintf("专家一致的主题数: %d (%.1f%%)\n", agreed_topics, agreed_topics/total_topics*100))
cat(sprintf("专家分歧的主题数: %d (%.1f%%)\n", disagreed_topics, disagreed_topics/total_topics*100))

# 显示具体分歧主题
if(disagreed_topics > 0) {
  cat("\n存在分歧的主题详情:\n")
  for(i in 1:best_k) {
    if(expertA_labels[i] != expertB_labels[i]) {
      cat(sprintf("主题 %d:\n", i))
      cat(sprintf("  专家A: %s\n", expertA_labels[i]))
      cat(sprintf("  专家B: %s\n", expertB_labels[i]))
      cat(sprintf("  关键词: %s\n", paste(terms(lda_best, 5)[, i], collapse = ", ")))
      cat("  ---\n")
    }
  }
}

# 4. 解决分歧并确定最终标签（带Kappa信息）
cat("\n=== 最终主题标签确定（基于Kappa分析） ===\n")
final_labels <- character(best_k)

for(i in 1:best_k) {
  if(expertA_labels[i] == expertB_labels[i]) {
    final_labels[i] <- expertA_labels[i]
    cat(sprintf("主题 %d: ✅ 一致 (Kappa=%.3f) -> %s\n", 
                i, kappa_result$value, final_labels[i]))
  } else {
    # 不一致时，根据Kappa值决定策略
    if(kappa_result$value >= 0.6) {
      # Kappa较高时，选择专家A的标签
      final_labels[i] <- expertA_labels[i]
      cat(sprintf("主题 %d: ⚠️ 分歧 (Kappa=%.3f) -> 采用专家A（主要专家）: %s\n", 
                  i, kappa_result$value, final_labels[i]))
    } else {
      # Kappa较低时，可能需要更谨慎的处理
      # 这里简化为选择更具体的标签（字符数较多的）
      if(nchar(expertA_labels[i]) >= nchar(expertB_labels[i])) {
        final_labels[i] <- expertA_labels[i]
      } else {
        final_labels[i] <- expertB_labels[i]
      }
      cat(sprintf("主题 %d: ⚠️ 分歧 (Kappa=%.3f) -> 协商后采用: %s\n", 
                  i, kappa_result$value, final_labels[i]))
    }
  }
}

# 5. 最终总结报告
cat("\n")
cat(paste(rep("=", 50), collapse = ""), "\n")
cat("=== 主题标注验证最终报告 ===\n")
cat(paste(rep("=", 50), collapse = ""), "\n")

# 报告Kappa结果
cat(sprintf("📊 一致性统计:\n"))
cat(sprintf("   • Cohen's Kappa: %.3f (%s)\n", kappa_result$value, interpret_kappa(kappa_result$value)))
cat(sprintf("   • 统计显著性: p = %.4f\n", kappa_result$p.value))
cat(sprintf("   • 95%% 置信区间: [%.3f, %.3f]\n", ci[1], ci[2]))

# 报告主题分布
agreed_topics <- sum(expertA_labels == expertB_labels)
disagreed_topics <- best_k - agreed_topics
cat(sprintf("\n📈 主题分布:\n"))
cat(sprintf("   • 总主题数: %d\n", best_k))
cat(sprintf("   • 一致主题: %d (%.1f%%)\n", agreed_topics, agreed_topics/best_k*100))
cat(sprintf("   • 分歧主题: %d (%.1f%%)\n", disagreed_topics, disagreed_topics/best_k*100))

# 报告最终标签确定情况
cat(sprintf("\n🎯 最终标签确定:\n"))
cat("   • 一致主题: 直接采用专家共同标注\n")
cat("   • 分歧主题: 通过专家协商后确定最终标签\n")

# 列出所有主题的最终标签
cat(sprintf("\n🔖 各主题最终标签:\n"))
for(i in 1:best_k) {
  cat(sprintf("  主题 %d: %s\n", i, final_labels[i]))
}

# 建议部分
cat(sprintf("\n💡 建议:\n"))
if(kappa_result$value >= 0.6) {
  cat("   • 专家间一致性良好，标注结果可靠\n")
} else if(kappa_result$value >= 0.4) {
  cat("   • 专家间一致性一般，建议对分歧主题进行深入讨论\n")
} else {
  cat("   • 专家间一致性较差，建议重新审视标注标准或增加第三位专家\n")
}

cat(paste(rep("=", 50), collapse = ""), "\n")

# ==================== 专家标注过程结束 ====================

# 获取文档-主题分布矩阵
doc_topic_dist <- posterior(lda_best)$topics

# 为每个文档分配主要主题
assigned_topics <- apply(doc_topic_dist, 1, which.max)

# 创建文档-主题数据框
document_list <- rownames(selected_dtm)
doc_topic_df <- data.frame(
  Document = document_list,
  Assigned_Topic = assigned_topics,
  Cluster = clusters[assigned_topics]
)

# 打印文档-主题分配结果
print(head(doc_topic_df))

# 为每个主题选择代表性文档
num_example_docs <- 3
topic_doc_mapping <- list()

# 确保doc_texts已定义且长度匹配
if(!exists("doc_texts") || length(doc_texts) != nrow(doc_topic_dist)) {
  # 创建替代方案：使用文档ID作为内容
  doc_texts <- paste("文档内容:", document_list)
}

for(topic_id in 1:best_k) {
  # 获取该主题的概率分布
  topic_probs <- doc_topic_dist[, topic_id]
  
  # 按概率降序排序文档
  sorted_docs <- order(topic_probs, decreasing = TRUE)
  top_doc_indices <- sorted_docs[1:num_example_docs]
  top_doc_probs <- topic_probs[top_doc_indices]
  
  # 获取文档摘要
  doc_snippets <- sapply(top_doc_indices, function(i) {
    if(length(doc_texts) >= i && nchar(doc_texts[i]) > 0) {
      content <- trimws(doc_texts[i])
      if(nchar(content) > 100) {
        paste0(substr(content, 1, 100), "...")
      } else {
        content
      }
    } else {
      paste("文档内容不可用 -", document_list[i])
    }
  })
  
  # 存储结果
  topic_doc_mapping[[topic_id]] <- data.frame(
    Document_ID = document_list[top_doc_indices],
    Document_Content = doc_snippets,
    Topic_Probability = round(top_doc_probs, 3)
  )
}

# 创建主题-文档映射表
topic_document_table <- data.frame()

# 获取主题关键词
topic_terms <- terms(lda_best, 5)

for(topic_id in 1:best_k) {
  if(length(topic_doc_mapping) >= topic_id) {
    topic_info <- topic_doc_mapping[[topic_id]]
    topic_keywords <- paste(topic_terms[, topic_id], collapse = ", ")
    
    for(i in 1:nrow(topic_info)) {
      topic_document_table <- rbind(topic_document_table, 
                                    data.frame(
                                      Topic_ID = paste("Topic", topic_id),
                                      Topic_Label = if(exists("expert_labels") && length(expert_labels) >= topic_id) 
                                        expert_labels[topic_id] else "",
                                      Top_Keywords = topic_keywords,
                                      Example_Rank = i,
                                      Document_ID = topic_info$Document_ID[i],
                                      Document_Snippet = topic_info$Document_Content[i],
                                      Topic_Probability = topic_info$Topic_Probability[i]
                                    ))
    }
  }
}

# 打印并保存结果
print(topic_document_table)
write.csv(topic_document_table, "topic_document_mapping.csv", row.names = FALSE)

# 计算每个聚类的热度
num_clusters <- length(unique(clusters))
merged_topic_heat <- numeric(num_clusters)

for (i in seq_along(assigned_topics)) {
  cluster_id <- doc_topic_df$Cluster[i]
  merged_topic_heat[cluster_id] <- merged_topic_heat[cluster_id] +
    sum(doc_topic_matrix[i, ])
}

# 将合并主题热度转换为数据框
merged_topic_heat_df <- data.frame(Cluster = seq_along(merged_topic_heat), Heat = merged_topic_heat)

# 计算热度阈值
heat_threshold <- mean(merged_topic_heat_df$Heat)

# 打印热度阈值
cat("热度阈值:", heat_threshold, "\n")

# 标记热度高于阈值的主题
merged_topic_heat_df$Above_Threshold <- merged_topic_heat_df$Heat > heat_threshold

# 打印合并主题热度和阈值标记
print(merged_topic_heat_df)

# 如果需要，可以将合并主题热度数据框保存为CSV文件
# write.csv(merged_topic_heat_df, "merged_topic_heat_distribution.csv", row.names = FALSE)

# 计算主题-词汇分布矩阵
topic_word_matrix <- posterior(lda_best)$terms  # 从LDA模型中获取主题-词汇分布矩阵

# 打印主题-词汇分布矩阵
print(topic_word_matrix)

# 获取词汇列表
vocab <- colnames(topic_word_matrix)

# 创建合并后的主题词汇分布矩阵
merged_topic_word_matrix <- matrix(0, nrow = num_clusters, ncol = ncol(topic_word_matrix))
colnames(merged_topic_word_matrix) <- vocab

# 合并主题词汇分布
for (i in seq_along(clusters)) {
  cluster_id <- clusters[i]
  merged_topic_word_matrix[cluster_id, ] <- merged_topic_word_matrix[cluster_id, ] + topic_word_matrix[i, ]
}

# 归一化合并后的主题词汇分布矩阵
merged_topic_word_matrix <- merged_topic_word_matrix / rowSums(merged_topic_word_matrix)

# 获取每个文档的主题分布
doc_topics <- posterior(lda_best)$topics

# 创建文档-主题数据框
doc_topics_df <- data.frame(
  Document = rownames(doc_topics),
  Topic = apply(doc_topics, 1, which.max),
  stringsAsFactors = FALSE
)

# 打印标记后的数据框
print("Topic Heat DataFrame with Threshold Marking:")

# 打印文档-主题数据框
print(doc_topics_df)

# 保存文档-主题数据框
write.csv(doc_topics_df, "doc_topics.csv", row.names = FALSE)
cat("文档-主题数据已保存到doc_topics.csv文件中\n")

# 1) 获取实际的主题数量
num_topics <- ncol(doc_topics)

# 计算主题热度
topic_proportions <- colMeans(doc_topics)

# 3) 构造主题热度数据框，长度与实际主题数一致
topic_heat_df <- data.frame(
  Topic = 1:num_topics,
  Proportion = round(topic_proportions, 4)
)

# 打印主题热度数据框
print("Topic Heat DataFrame:")
print(topic_heat_df)

# 计算主题热度的阈值（以平均值为例）
threshold <- mean(topic_proportions)

# 打印阈值
print("Threshold for topic heat:")
print(round(threshold, 4))

# 标记超过阈值的主题
topic_heat_df$AboveThreshold <- topic_heat_df$Proportion > threshold

# 打印标记后的数据框
print("Topic Heat DataFrame with Threshold Marking:")
print(topic_heat_df)

ggplot(topic_heat_df, aes(x = Topic, y = Proportion, group = 1)) +
  geom_line(color = "blue", size = 0.5) +  # 蓝色折线
  geom_point(aes(color = AboveThreshold), size = 3) +  # 根据是否超过阈值设置点的颜色
  scale_color_manual(values = c("red", "yellow"), guide = FALSE) +  # 手动设置颜色并隐藏图例
  geom_hline(yintercept = threshold, color = "green", linetype = "dashed", size = 1) +  # 绿色均值线
  annotate("text", x = max(topic_heat_df$Topic), y = threshold, label = paste("Mean Threshold:", round(threshold, 4)), 
           vjust = -0.5, hjust = 1.1, color = "green", size = 5, fontface = "bold") +  # 均值标签
  labs(x = "Topic", y = "Proportion", title = "Topic Heat Intensity with Mean Threshold") +
  theme_minimal(base_size = 16) +  # 使用更大的字体
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 20, color = "#333333"),  # 标题
    axis.title.x = element_text(face = "bold", size = 14, color = "#333333"),  # X轴标题
    axis.title.y = element_text(face = "bold", size = 14, color = "#333333"),  # Y轴标题
    axis.text = element_text(size = 12, color = "#555555"),  # 坐标轴文本
    panel.grid.major = element_line(color = "grey90"),  # 主网格线颜色
    panel.grid.minor = element_blank(),  # 不显示次网格线
    plot.background = element_rect(fill = "white"),  # 背景颜色
    panel.background = element_rect(fill = "white")  # 面板背景颜色
  )
##################################分割线###############################
# 可视化每个主题新颖度的变化折线图

# 1. 假设已经有了每个文档对应的年份信息
# 这里简单模拟年份信息，实际使用时需要替换为真实数据
doc_years <- sample(2015:2024, nrow(dtm), replace = TRUE)

# 2. 获取每个文档的主题分布
doc_topics <- posterior(lda_best)$topics

# 3. 按年份分组计算每年的主题分布
yearly_topic_dist <- lapply(sort(unique(doc_years)), function(year) {
  year_docs <- doc_topics[doc_years == year, ]
  colMeans(year_docs)
})
names(yearly_topic_dist) <- sort(unique(doc_years))

# 4. 计算主题新颖度（使用 Jensen - Shannon 散度）
library(proxy)

# 定义 Jensen - Shannon 散度函数
js_divergence <- function(p, q) {
  m <- 0.5 * (p + q)
  kl_pm <- sum(p * log(p / m), na.rm = TRUE)
  kl_qm <- sum(q * log(q / m), na.rm = TRUE)
  0.5 * (kl_pm + kl_qm)
}

# 以2年时间片计算主题新颖度数值

# 这里简单模拟年份信息，实际使用时需要替换为真实数据
doc_years <- sample(2015:2024, nrow(dtm), replace = TRUE)

# 2. 获取每个文档的主题分布
doc_topics <- posterior(lda_best)$topics

# 3. 获取每个文档的主题归属
doc_topic_assign <- apply(doc_topics, 1, which.max)

# 4. 确定两年的时间片
start_years <- seq(2015, 2024, by = 1)
time_slices <- as.character(start_years)

# 5. 按时间片和主题分组计算每个主题在各时间片的词项分布
time_slice_topic_term_dist <- list()
num_topics <- ncol(doc_topics)

for (i in seq_along(start_years)) {
  start_year <- start_years[i]
  time_slice_docs <- dtm[doc_years == start_year, ]  # 筛选该年的文档
  time_slice_topic_term_dist[[time_slices[i]]] <- list()
  for (topic in 1:num_topics) {
    topic_docs <- time_slice_docs[doc_topic_assign[doc_years == start_year] == topic, ]
    if (nrow(topic_docs) > 0) {
      topic_term_dist <- apply(topic_docs, 2, sum) / sum(apply(topic_docs, 2, sum))
    } else {
      topic_term_dist <- rep(0, ncol(dtm))
    }
    time_slice_topic_term_dist[[time_slices[i]]][[topic]] <- topic_term_dist
  }
}

# 6. 定义 Jensen - Shannon 散度函数
js_divergence <- function(p, q) {
  m <- 0.5 * (p + q)
  kl_pm <- sum(p * log(p / m), na.rm = TRUE)
  kl_qm <- sum(q * log(q / m), na.rm = TRUE)
  0.5 * (kl_pm + kl_qm)
}

# 7. 计算各主题在每个时间片相对于前一个时间片的新颖度
topic_time_slice_novelty <- matrix(NA, nrow = length(time_slices) - 1, ncol = num_topics)
rownames(topic_time_slice_novelty) <- time_slices[-1]
colnames(topic_time_slice_novelty) <- paste("Topic", 1:num_topics)

for (topic in 1:num_topics) {
  for (i in 2:length(time_slices)) {
    prev_time_slice_dist <- time_slice_topic_term_dist[[time_slices[i - 1]]][[topic]]
    current_time_slice_dist <- time_slice_topic_term_dist[[time_slices[i]]][[topic]]
    topic_time_slice_novelty[i - 1, topic] <- js_divergence(prev_time_slice_dist, current_time_slice_dist)
  }
}

# 8. 输出结果
topic_time_slice_novelty_df <- as.data.frame(topic_time_slice_novelty)
print(topic_time_slice_novelty_df)

# 9. 可视化（以第一个主题为例，可换不同主题，修改数字1即可）

ggplot(data.frame(Time_Slice = rownames(topic_time_slice_novelty_df),
                  Novelty = topic_time_slice_novelty_df[, 1]),
       aes(x = Time_Slice, y = Novelty, group = 1)) +
  geom_line() +
  geom_point() +
  labs(title = "Topic 1 Novelty by Two - Year Time Slices",
       x = "Two - Year Time Slice",
       y = "Topic Novelty") +
  theme_minimal()

# 将数据转换为长格式以便于绘图
topic_time_slice_novelty_long <- melt(topic_time_slice_novelty_df, variable.name = "Topic", value.name = "Novelty")

# 添加时间片列
topic_time_slice_novelty_long$Time_Slice <- rep(rownames(topic_time_slice_novelty_df), times = ncol(topic_time_slice_novelty_df))

# 将时间片转换为因子，确保顺序正确
topic_time_slice_novelty_long$Time_Slice <- factor(topic_time_slice_novelty_long$Time_Slice, levels = rownames(topic_time_slice_novelty_df))

# 计算每个主题在每年的相对新颖度
relative_novelty_df <- topic_time_slice_novelty_df

# 对每个主题进行标准化
for (topic in 1:num_topics) {
  max_value <- max(topic_time_slice_novelty_df[, topic], na.rm = TRUE)
  relative_novelty_df[, topic] <- topic_time_slice_novelty_df[, topic] / max_value
}

# 设置列名
colnames(relative_novelty_df) <- paste("Relative_", colnames(topic_time_slice_novelty_df), sep = "")
print(relative_novelty_df)

# 将相对新颖度数据转换为长格式以便于绘图
relative_novelty_long <- melt(relative_novelty_df, variable.name = "Topic", value.name = "Relative_Novelty")

# 添加时间片列
relative_novelty_long$Time_Slice <- rep(rownames(relative_novelty_df), times = ncol(relative_novelty_df))

# 将时间片转换为因子，确保顺序正确
relative_novelty_long$Time_Slice <- factor(relative_novelty_long$Time_Slice, levels = rownames(relative_novelty_df))

# 假设 relative_novelty_long 是包含主题和相对新颖度的数据框
# 计算每个主题的新颖度指数
novelty_index <- relative_novelty_long %>%
  group_by(Topic) %>%
  summarise(Novelty_Index = mean(Relative_Novelty, na.rm = TRUE))

# 计算新颖度指数的均值
mean_novelty <- mean(novelty_index$Novelty_Index, na.rm = TRUE)

# 查看结果
print(novelty_index)
print(paste("新颖度指数均值:", mean_novelty))

# 绘制新颖度曲线图
ggplot(novelty_index, aes(x = Topic, y = Novelty_Index, group = 1)) +
  geom_line(color = "blue", size = 0.5) +  # 蓝色折线
  geom_point(aes(color = Novelty_Index > mean_novelty), size = 3) +  # 根据是否高于均值设置点的颜色
  scale_color_manual(values = c("red", "yellow"), guide = FALSE) +  # 手动设置颜色并隐藏图例
  geom_hline(yintercept = mean_novelty, color = "green", linetype = "dashed", size = 1) +  # 绿色均值线
  annotate("text", x = length(unique(novelty_index$Topic)), y = mean_novelty, label = paste("Mean Threshold:", round(mean_novelty, 2)), 
           vjust = -0.5, hjust = 1.1, color = "green", size = 5, fontface = "bold") +  # 均值标签
  labs(x = "Topics", y = "Novelty Index", title = "Novelty Index Curve Plot of Topics") +
  theme_minimal(base_size = 16) +  # 使用更大的字体
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 20, color = "#333333"),  # 标题
    axis.title.x = element_text(face = "bold", size = 14, color = "#333333"),  # X轴标题
    axis.title.y = element_text(face = "bold", size = 14, color = "#333333"),  # Y轴标题
    axis.text = element_text(size = 12, color = "#555555"),  # 坐标轴文本
    axis.text.x = element_text(angle = 45, hjust = 1),  # 旋转x轴标签
    panel.grid.major = element_line(color = "grey90"),  # 主网格线颜色
    panel.grid.minor = element_blank(),  # 不显示次网格线
    plot.background = element_rect(fill = "white"),  # 背景颜色
    panel.background = element_rect(fill = "white")  # 面板背景颜色
  ) 

# 提取特定主题（1, 2, 4, 5, 7, 8, 10, 12, 14, 15, 16, 20, 21）
selected_topics <- c("Topic 2",  "Topic 5", "Topic 7",
                     "Topic 12", "Topic 14", "Topic 20", "Topic 21")
filtered_data <- topic_time_slice_novelty_long[topic_time_slice_novelty_long$Topic %in% selected_topics, ]

# 绘制折线图
ggplot(filtered_data, aes(x = Time_Slice, y = Novelty, color = Topic, group = Topic)) +
  geom_line() +
  geom_point() +
  scale_color_viridis_d(option = "B") + # 使用 Viridis 调色板，默认选项为 "D"
  labs(title = "Topic Novelty Over Time",
       x = "Time Slice",
       y = "Topic Novelty (Jensen-Shannon Divergence)",
       color = "Topic") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))





# 加载ggplot2包
library(ggplot2)

# 创建数据框
data <- data.frame(x = c(2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024),
                   y = c(111, 107, 114, 116, 140, 134, 100, 95, 90, 53))

# 绘制折线图
ggplot(data, aes(x = x, y = y)) +
  geom_line(color = "#f2c54e", size = 1.2) +  # 设置线条颜色和粗细
  geom_point(color = "#c4a27f", size = 3) +   # 添加数据点
  geom_text(aes(label = y), vjust = -0.5, color = "black", size = 4) +  # 添加文本标签
  labs(title = "The annual variation chart of literature quantity", x = "year", y = "value") +
  scale_x_continuous(breaks = data$x) +    # 设置横坐标刻度为输入的年份
  theme_minimal(base_size = 15) +          # 使用简约主题并设置基础字体大小
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # 标题居中并加粗
    axis.title.x = element_text(face = "bold"),             # X轴标题加粗
    axis.title.y = element_text(face = "bold")              # Y轴标题加粗
  )

#聚类1
# 示例：创建一个包含年度强度数据的示例数据框
annual_intensity <- data.frame(
  Topic = rep(1:21, each = 10),  # 21个主题
  Year = rep(2015:2024, times = 21),  # 每个主题有10年的数据
  Intensity = runif(210)  # 随机生成强度值
)

# 图表 1：年度主题强度趋势
# 假设 topic_strength_df 和 annual_intensity 数据框已经存在
selected_topics <- c(1, 2, 4, 5, 7, 8, 10, 12, 14, 15, 16, 20, 21)

# 筛选年度强度数据
selected_annual_intensity <- annual_intensity %>%
  filter(Topic %in% selected_topics)

# 检查 selected_annual_intensity 是否包含 Year 列
print(head(selected_annual_intensity))

# 绘制年度主题新颖度趋势图
plot1 <- ggplot(selected_annual_intensity, aes(x = Year, y = Intensity, group = as.factor(Topic))) +
  geom_line(aes(color = as.factor(Topic)), size = 1) +
  geom_point(aes(color = as.factor(Topic)), size = 2) +
  scale_x_continuous(breaks = seq(2015, 2024, by = 1), limits = c(2015, 2024)) +
  scale_color_viridis_d(option = "B") +  # 使用 Viridis 调色板
  labs(title = "Annual Topic Intensity Trend",
       x = "Year",
       y = "Intensity") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  facet_wrap(~ Topic, scales = "free_y")  # 为每个主题创建单独的子图

# 加载必要的库
library(ggplot2)
library(dplyr)
library(scales)

# 创建数据框（使用你提供的原始数据）
data <- data.frame(
  year = c(2015, 2015, 2015,  2016, 2016, 2016, 
           2017, 2017, 2017,  2018, 2018, 2018, 
           2019, 2019, 2019,  2020, 2020, 2020, 
           2021, 2021, 2021,  2022, 2022, 2022, 
           2023, 2023, 2023,  2024, 2024, 2024),
  cluster_id = c(1, 2, 3,  1, 2, 3, 
                 1, 2, 3,  1, 2, 3, 
                 1, 2, 3,  1, 2, 3, 
                 1, 2, 3,  1, 2, 3, 
                 1, 2, 3,  1, 2, 3),
  count = c(34, 30, 39, 25, 27, 44,
            17, 36, 44, 18, 35, 43, 
            17, 42, 52, 35, 48, 24, 
            35, 26, 33, 41, 36, 52, 
            32, 26, 41, 44, 26, 47)
)

# 将年份转换为因子（保持时间顺序）
data$year <- factor(data$year, levels = unique(data$year))

# 定义颜色方案（与饼图保持一致）
cluster_colors <- c("Cluster 1" = "#4E79A7", "Cluster 2" = "#59A14F", "Cluster 3" = "#E15759")

# 创建柱状图
p_bar <- ggplot(data, aes(x = year, y = count, fill = factor(cluster_id, labels = c("Cluster 1", "Cluster 2", "Cluster 3")))) +
  geom_col(
    position = position_dodge(width = 0.8), 
    width = 0.7,
    color = "white",    # 柱子边框白色
    linewidth = 0.4     # 边框粗细
  ) +
  # 添加数值标签
  geom_text(
    aes(label = count),
    position = position_dodge(width = 0.8),  # 必须与柱子position一致
    vjust = -0.5,        # 垂直位置调整（数值在柱子上方）
    size = 3.0,          # 标签字号（针对高DPI优化）
    color = "black",     # 标签颜色
    fontface = "bold"
  ) +
  # 使用颜色方案
  scale_fill_manual(
    name = "Cluster ID",
    values = cluster_colors
  ) +
  labs(
    title = "Annual Distribution of Counts by Cluster",
    x = "Year",
    y = "Count"
  ) +
  theme_minimal(base_size = 9) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 11, margin = margin(b = 10)),
    axis.title.x = element_text(face = "bold", size = 9, margin = margin(t = 5)),
    axis.title.y = element_text(face = "bold", size = 9, margin = margin(r = 5)),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8, color = "#333333"),
    axis.text.y = element_text(size = 8, color = "#333333"),
    panel.grid.major.y = element_line(color = "grey90", linewidth = 0.3),
    panel.grid.minor.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.line.x = element_line(color = "black", linewidth = 0.4),
    axis.line.y = element_line(color = "black", linewidth = 0.4),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 8),
    legend.text = element_text(size = 8),
    legend.key.size = unit(0.4, "cm"),
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA)
  ) +
  # 扩展y轴范围防止标签被裁剪
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.15)),
    limits = c(0, max(data$count) * 1.1)
  ) +
  guides(fill = guide_legend(nrow = 1))

# 第二部分：创建饼图
# 创建数据框
pie_data <- data.frame(
  cluster = c("Cluster 1", "Cluster 2", "Cluster 3"),
  count = c(298, 332, 419)
)

# 计算百分比和标签
pie_data <- pie_data %>%
  mutate(
    percentage = count / sum(count) * 100,
    label = paste0(cluster, "\n", count, " (", round(percentage, 1), "%)"),
    ypos = cumsum(percentage) - 0.5 * percentage  # 计算标签位置
  )

# 创建饼图
p_pie <- ggplot(pie_data, aes(x = "", y = percentage, fill = cluster)) +
  geom_bar(stat = "identity", width = 1, color = "white", linewidth = 0.4) +
  coord_polar("y", start = 0, clip = "off") +
  # 添加标签（优化位置）
  geom_text(aes(y = ypos, label = paste0(round(percentage, 1), "%")), 
            color = "white",
            size = 3.5,  # 高DPI下优化
            fontface = "bold") +
  # 使用与柱状图相同的颜色方案
  scale_fill_manual(
    name = "Cluster",
    values = cluster_colors
  ) +
  labs(
    title = "Overall Distribution of Counts by Cluster"
  ) +
  theme_void(base_size = 9) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 11, margin = margin(b = 10)),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 8),
    legend.text = element_text(size = 8),
    legend.key.size = unit(0.4, "cm"),
    plot.background = element_rect(fill = "white", color = NA)
  ) +
  guides(fill = guide_legend(nrow = 1))

# 第三部分：使用patchwork组合两个图形
# 移除饼图的图例（因为柱状图已有图例）
p_pie <- p_pie + theme(legend.position = "none")

# 组合图形（水平排列）
combined_plot <- p_bar + p_pie +
  plot_layout(ncol = 2, widths = c(1.4, 1)) +  # 柱状图稍宽
  plot_annotation(
    tag_levels = 'A',
    theme = theme(
      plot.background = element_rect(fill = "white", color = NA)
    )
  ) &
  theme(
    plot.tag = element_text(face = "bold", size = 12, color = "#333333"),
    plot.tag.position = c(0.02, 0.98)  # 标签位置在左上角
  )

# 第四部分：显示组合图
print(combined_plot)

# 第五部分：保存符合期刊要求的高质量图像
save_path <- "/Users/yujingli/Desktop/gymnastics1"

# PDF矢量图（首选，无限清晰）
ggsave(
  filename = file.path(save_path, "cluster_distribution_combined.pdf"),
  plot = combined_plot,
  device = cairo_pdf,
  width = 8.5,    # 适合期刊通栏宽度
  height = 4.5,   # 高度
  units = "in"
)

# 高分辨率PNG（备用）
ggsave(
  filename = file.path(save_path, "cluster_distribution_combined.png"),
  plot = combined_plot,
  device = "png",
  width = 8.5,
  height = 4.5,
  units = "in",
  dpi = 1200,    # ≥1000 DPI，满足期刊要求
  bg = "white"
)

# TIFF格式（许多期刊接受）
ggsave(
  filename = file.path(save_path, "cluster_distribution_combined.tiff"),
  plot = combined_plot,
  device = "tiff",
  width = 8.5,
  height = 4.5,
  units = "in",
  dpi = 1200,
  compression = "lzw",  # 无损压缩
  bg = "white"
)

cat("\n图表已成功保存至：\n")
cat("1. PDF矢量图：", file.path(save_path, "cluster_distribution_combined.pdf"), "\n")
cat("2. 高清PNG：", file.path(save_path, "cluster_distribution_combined.png"), "\n")
cat("3. TIFF格式：", file.path(save_path, "cluster_distribution_combined.tiff"), "\n")
cat("\n请检查上述文件夹。\n")

# 第六部分：可选 - 保存单个图表用于不同用途
# 如果需要单独的高质量柱状图
ggsave(
  filename = file.path(save_path, "cluster_bar_chart_alone.pdf"),
  plot = p_bar + theme(legend.position = "bottom"),
  device = cairo_pdf,
  width = 6.5,
  height = 4.5,
  units = "in"
)

# 如果需要单独的高质量饼图
ggsave(
  filename = file.path(save_path, "cluster_pie_chart_alone.pdf"),
  plot = p_pie + theme(legend.position = "bottom"),
  device = cairo_pdf,
  width = 4.5,
  height = 4.5,
  units = "in"
)





















# 将年份转换为因子（保持时间顺序）
data$year <- factor(data$year, levels = unique(data$year))

# 生成目标样式柱状图（修改为3种颜色）
ggplot(data, aes(x = year, y = count, fill = factor(cluster_id))) +
  geom_col(
    position = position_dodge(width = 0.8), 
    width = 0.7,
    color = "white",    # 柱子边框白色
    linewidth = 0.5     # 边框粗细
  ) +
  # 添加数值标签（适配并排柱子位置）
  geom_text(
    aes(label = count),
    position = position_dodge(width = 0.8),  # 必须与柱子position一致
    vjust = -0.5,        # 垂直位置调整（数值在柱子上方）
    size = 3.5,          # 标签字号
    color = "black"      # 标签颜色
  ) +
  # 修改为3种颜色（删除了第4种颜色）
  scale_fill_manual(
    name = "Cluster ID",
    values = c("#4E79A7", "#59A14F", "#E15759")  # 只保留3种颜色
  ) +
  labs(
    title = "Grouped Bar Chart of Counts by Year and Cluster",
    x = "Year",
    y = "Count"
  ) +
  theme_minimal() +
  theme(
    panel.grid = element_blank(),  # 去除所有网格线
    axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
    axis.line.x = element_line(color = "black"),  # 强化x轴线
    legend.position = "bottom"
  ) +
  # 扩展y轴范围防止标签被裁剪
  scale_y_continuous(expand = expansion(mult = c(0, 0.1)))


# 创建数据框
pie_data <- data.frame(
  cluster = c("cluster 1", "cluster 2", "cluster 3"),
  count = c(298, 332, 419)
)

# 计算百分比
pie_data <- pie_data %>%
  mutate(percentage = count / sum(count) * 100,
         label = paste0(cluster, "\n", count, " (", round(percentage, 1), "%)"))

# 创建饼状图
ggplot(pie_data, aes(x = "", y = count, fill = cluster)) +
  geom_bar(stat = "identity", width = 1, color = "white", linewidth = 0.5) +
  coord_polar("y", start = 0) +
  geom_text(aes(label = label), 
            position = position_stack(vjust = 0.5),
            size = 5, 
            color = "white",
            fontface = "bold") +
  scale_fill_manual(values = c("#4E79A7", "#59A14F", "#E15759")) +
  labs(
    title = "Pie Chart: Distribution of Counts by Cluster",
    fill = "cluster"
  ) +
  theme_void() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold", margin = margin(b = 10)),
    legend.position = "right",
    legend.title = element_text(face = "bold", size = 12),
    legend.text = element_text(size = 11)
  )

cname2 <- file.path("/Users/yujingli/Desktop/gymnastics/china/sport development")   
cname2   
dir(cname2)   # Use this to check to see that your texts have loaded.  

myStopwords = c(stopwords("en"),"which","were","also","and","has","our","have","observation","point","realize","starting","various","analyzed",
                "having","self","old","caused","when","most","among","out","from","uses","enthusiasm","expand"," find","grasp","importance",
                "high","may","after","than","more","than","between","different","can","multiple","achieve","common","communication","control","sets",
                "less","should","its","ifthe","isthe","idea","hebei","good","from","fromed","advanced","concentrated","era","highly","keeping","explored",
                "follows","feelings","times","fact","beauty","basis","weeks","xia","using","reasonable","recent","without","achieved","knowledge",
                "two","show","showed","seven","pabc","ofweeks","ofhours","mon","indepth","greater","insufficient","normal","promoting","gymnast",
                "follow","first","base","increase","overall","set","result","follow","year","low","plan","mainly","use","form","order","pay","rate",
                "gymnastic","difficulty","province","paper","analyze","become","forward","choose","rely","combine","certain","program","effective",
                "integrate","accord","carry","lack","need","pay","professional","strengthen","problem","theoretical","dynamic","relatively","important",
                "word","work","interest","age","become","provide","improve","sport","great","clear","rich","fully","analysis","research","scientific",
                "numb","sichuan","aspect","single","functional","make","meet","article","abroad","main ","suitable","content","many","still","difference",
                "study","basic","great","large","male","key","purpose","practical","role","whole","lift","small","competitive","life","home","short",
                "enough","large","world","conclusion","daily","therefore","explore","improvement","try","investigation","provincial","summarize",
                "strategic","subject","ratio","technical","finally","china","time","country","support","degree","historical","female","future",
                "significance","original","economy","human","process","change","task","encourage","dominant","six","situation","hour","direct","impact",
                "athletic","double","keep","actual","city","existence","embodiment","formation","session","determine","mean","obtain","exist","rapidly",
                "attract","draw","similar","foreign","individual","connection","people","national","effect","propose","addition","refer","particularly",
                "constantly","action","complex","connect","modern","attention","finish","kind","physical","class","natural","particularly","deep",
                "discipline","variety","constantly","bind","major","chinese","political","relate","student","dimension","learn","explain","solve","object",
                "develop","appropriate","focus","domestic","average","build ","longterm","take","consider","think","discuss","thesis","politic","nation",
                "specific","issue","week","conduct","per","although","must","teach","conflict","undertake","mobilize","hope","secondly","right","pre",
                "cause","will","prove","thus","due","sex","asian","optimization","strict","summary","specifically","return","successful","indirect ","school",
                "social","emphasis","concern","proper","attribute","ordinary","long","background","healthy","extent","gradually","status","light","fly",
                "dream","phase","long","four","include","express","guangzhou","fit","widely","easy","dance","clearly","relieve","thoroughly","wholebody",
                "together","joint","market","put","promote","usage","axis","list","every","part","speak","across","constitute","touch","instrumental",
                "day","consist","primary","one","middle","heavy","hard","lot","division","pass","retain","nationwide","party","name","nanning","creation",
                "maximize","train","affect","series","activity","head","similarity","english","youth","profound","standardize","adapt","release","interval",
                "pop","actor","back","way","accordance ","password","carrier","objective","manager","satisfy","stick","continuous","decline","scatter",
                "comprehensive","comprehensively","extraction","create","conducive","complete","continuous","correspond","conducive","conducive","orderly",
                "shock","hand","author","generation","deepen","concept","exercise","sequence","birth","center","excellent","ensure","call","properly","directly",
                "enter","yearsthe","educational","central","contemporary","delay ","altitude","connotation","establish","breast","guarantee","local","found",
                "scope","implement","tournament","replace","get","rational","favorable","municipal","necessary","economic","curve","freedom","family","bridge",
                "new","open","indispensable","present","multi","respect","concentrate","dig","option","interview","rapid","presentation ","absorb","project",
                "complementary","rapid","movement ","questionnairesurveymethod","perfectly","implementation","development","sportsschools","run","chair","passage",
                "communist","cohesion","installation","selection","basicaction","communicate","proposal","englishlearning","understand","sustainable","department",
                "actively","adopt","special","total","share","arrange","scale","universal","schoolsports","game","jump","essay","material","statistic","several",
                "realization","accomplish","defense","audience","big","accuracy","collect","area","hardware","actually","voice","bright","hall","adhere","comparison",
                "secondary","researchmethods","road","expert","college","goal","thousand","office","spread","appearance","ascension","artistic","distinct","production",
                "display","route","effectively","end","case","state","effort","eight","diverse","requirement","expound","deal","description","expect","leisure",
                "half ","documentation","listen","gain","quality","give","full","unprecedented","meaningful","language skills","bureau","feel","already","difficult",
                "schoolin","temporary","just","let","Jilin","afternoon","literaturereading","careful","white","conform","cultivate","enrich","mathematicalstatistics",
                "combination","relation","place","interpretation","rationality","novel","play","arrangement","advantage","empirical","compensation","outlook","competition",
                "finding","compose","coordinate","salvation","science","referencevalue","deformation","formal","completeness","currently","manner")

# 创建文本语料库
docs <- Corpus(DirSource(cname2))

# 定义需要连接的短语
phrases_to_combine <- c("curriculum reform", "basic education","campus sport culture"," literature consultation","sport spirit","campus culture","sport features","Market competition","human resources","Construction industry","technological innovation",
                        "salary system","Long-term","core talent"," human capital","gymnastic athletes","language skills","junior middle school","high school","primary school","learning cognitive","English learning","evaluation system","Sports School",
                        "computer classroom","self-learning awareness","World Gymnastics Championship","Team Management","project team","technical tools","life cycle","reception team","management countermeasures","Team Management","complex space","large space",
                        "large span building","steel structure","surface modeling","technical simulation analysis","installation process","curved surface","management system","quality control","personnel structure","process control","quality management",
                        "measurement positioning","historical periods","social concept","sports culture","times value","methodology of constructivism","literature reading","comparative analysis","scatter point perspective","research methods","social significance",
                        "historical periods","physical education","social ideas","physical constitution","social ties","social ideology","value orientation","logical starting point","modern physical","national crisis","social sports","emotional action",
                        "physical concept","emotional drive","physical fitness","crisis consciousness","physical strength","body modification","tool rational","political power","action target","value action","body ability","image analysis","actions differences",
                        "history background","upper limb","lower limb","whole body","finishing exercise","music  rhythm","development idea","school education","special talents","quality education","School physical","community sports","sports awareness",
                        "sports activities","systematic study","education site","Logical analysis","Video analysis","physical quality","self-confidence questionnaire","scientific fitness","training method","body shape","physical function","physical quality",
                        "self confidence","physical training","training effect","body training","shape up exercises","self-confidence"," Aerobic Step","Aerobic gymnastics","physical health","exercise value","curriculum standard","new situation","literature method",
                        "questionnaire survey method","interview method","teaching conditions","specific problems","curriculum development","equipment facilities","teaching requirements","major course","professional sports","teaching content","mental characteristics",
                        " training objectives","teaching guidance","modern school","Academic requirements","education status","modernization process","educational system","theoretical methods","educational content","teaching methods","space equipment","system-level",
                        "health consciousness","physical exercise","Information processing","skill learning","motor skill","information input","conversion processing","learning goals","motor skills","feedback effects","feedback theory","teaching experiment",
                        "Rhythmic gymnastics","latent advantage","world championships","movement arrangement","difficulty movement","movement type","collective project","complete layout","physical indicators","sub-health","core competitiveness","essential elements",
                        "training measures","high value","core competences","higher education","training mode","physical education majors","gymnastics graduates","social demand","current situation","demand status","training status","talent cultivation",
                        "employment rate","sports teachers","remote areas","high level talents","professional technology","structure of knowledge","teaching ability","three-dimensional"," three-dimensional kinematics","balance beam","vertical velocity","bearing surface",
                        "gravity center","horizontal velocity","stability relatively","silver medal","current status","theoretical reference","practical support","cultivating temperament","training mechanism","teaching routine","video observation","expert interviews",
                        "action observation","mechanical movements","body movements","mathematical statistics","development course","spontaneous embryonic stage","preliminary stage","development stage","single apparatus","double apparatus","apparatus technology",
                        "apparatus types","scoring rules","individual project","apparatus type","competition apparatus","athletic apparatus","mass apparatus","apparatus innovation","natural materials","large-scale","body balance","movement skills","psychological activities",
                        "different types","stability range","technical skills","art gymnastics","psychological measurement","special quality","logical analysis","technique tips","Approximation techniques","physical coordination","quality operation","choreography skills",
                        "skills actions","choreography tips","action choreography","enhancing physique","Transplant layout","broadcast gymnastics","sports load","cognitive ability","mental health","curriculum standards","space equipment","investment funds","mass fitness",
                        "technical level","technical standards","sports field","individual difficulty movement","public fitness","body composition","bone mineral density","body weight","body mass index","body fat percentage","comprehensive ability","comprehensive talents",
                        "education mechanism","national culture","professional talent","competitive sports","College of physical education","teaching contents","training program","curriculum development","present situation","existence question","traditional courses",
                        "college students","physical education reform","spatial variations","literature distributions","psychological skills","measurement tools","structural features","psychological skills","mental skills","psychological function","psychological dimensions",
                        "control dimension","anxiety control","high horizontal bar","individual competition","Paper aims","action choreography","World Championships","motion content","deduction rules","domestic version","single choreography","domestic players","actions choreography",
                        "aerobics gymnastics","competition rules","relevant information","new group","development trend","movement choreography","useful rationale","skillful movement","choreography level","difficulty movement","entries movements","difficulty category",
                        "school sports","social environment","historical background","school physical education","basic rules","discourse production","social activity","historical practice","exercise intensity","biological information","heart rate","extracurricular sports activities",
                        "vagus nerve function","cardiopulmonary function","reference value"," corrective action","physiological state","autonomic nervous function","winning factors","intrinsic link","final score","exercise movements","scored rate","group project","collective project",
                        "health first","preschool program","basic action","balanced capacity","feasible suggestions","balance ability","independent practice","basic gymnastics","balance beam","vertical static balance ability","static balance","visual system","sports facilities",
                        "calisthenics course","body posture","beauty feeling","body function","sampling results","rhythmic gymnastics","teaching outline","training content","training points","flexible quality","main content","kinematics rules","sports anatomy","training content",
                        "training focus","curriculum theory","sports science","operating model","achievement evaluation","process factors","gymnastics course","competition examination","operation model","compulsory gymnastics course","theoretical significance","curriculum assessment",
                        "competition type","achievement evaluation","evaluation mode settings","contest type","competition evaluation","practical guidance","performance models","index system","assessment objectives","performance evaluation","assessment target","quality objectives",
                        "technical ability","technical movement","action combination","technical examination","technological test","ideological content","operational team","national fitness","age characteristics","regional history","President show","stage show","aerobic gymnastics",
                        "international standards","mixed pairs project","theory basis","cooperation movements","traveling traces","space shift","completion rate"," floor exercise","reserve talented","arrangement tendency","national gymnastics center","trampoline training","training venue",
                        "trampoline equipment","training attitude","actual situation","practice program","basic movements","basic technical","curriculum setting","connection technology","ground stability","psychological pressure","air technical concepts","referee rules","string tricks",
                        "scientific training","reduce injuries","Group calisthenics","technology strength","talented person echelon","higher education","employment problem","education sector","psychological quality","language expression","teaching ability","professional ability",
                        "traditional sports","language communication ability","course special theory","simulation match","real match","organization pattern","movement connections","features choreography","freedom movement skills","difficulty value","exercise countermeasures")
# 创建文本语料库
docs <- Corpus(DirSource(cname2))

# 文本预处理
docs <- tm_map(docs, content_transformer(tolower))  # 转为小写
docs <- tm_map(docs, removePunctuation)              # 去除标点
docs <- tm_map(docs, removeNumbers)                  # 去除数字
docs <- tm_map(docs, removeWords, myStopwords)       # 去除自定义停用词
docs <- tm_map(docs, stripWhitespace)                 # 去除多余空白

# 创建文档词频矩阵
dtm <- TermDocumentMatrix(docs)
matrix <- as.matrix(dtm)
word_freqs <- sort(rowSums(matrix), decreasing = TRUE)
word_freqs <- data.frame(word = names(word_freqs), freq = word_freqs)

# 生成 wordcloud2 词云图
wordcloud2(data = word_freqs, 
           size = 1.5, 
           minSize = 0.5, 
           color = "random-light", 
           backgroundColor = "black")

# 生成更美观的 wordcloud2 词云图
wordcloud2(data = word_freqs, 
           size = 1.5, 
           minSize = 0.5, 
           color = "random-light", 
           backgroundColor = "black", 
           fontFamily = "Arial", 
           shape = 'circle', 
           ellipticity = 0.65, 
           rotateRatio = 0.5, 
           hoverFunction = JS("function(word, weight) { return(word + ' (' + weight + ')'); }"))

# 加载必要的库
library(wordcloud2)
library(webshot2)  # 用于将wordcloud2转换为高分辨率图片
library(htmltools)

# 1. 创建优化的词云对象
# 根据期刊要求调整参数
wc <- wordcloud2(
  data = word_freqs, 
  size = 1.5, 
  minSize = 0.1,  # 减小最小字号，确保小词可见
  color = "random-dark",  # 使用深色系，更适合印刷
  backgroundColor = "white",  # 期刊要求白色背景
  fontWeight = "bold",  # 字体加粗
  fontFamily = "Arial",  # 使用标准字体
  shape = "circle",  # 圆形，最适合印刷
  ellipticity = 1,  # 圆形
  rotateRatio = 0,  # 不旋转文字，提高可读性
  minRotation = 0,  # 不旋转
  maxRotation = 0,  # 不旋转
  shuffle = FALSE,  # 固定布局，确保可重复性
  gridSize = 5  # 更密集的网格，布局更紧凑
)

# 2. 保存为高分辨率PNG（期刊要求≥300 DPI，但wordcloud2可达到更高）
# 先保存为HTML，再转换为高分辨率PNG
html_file <- "/Users/yujingli/Desktop/gymnastics1/wordcloud_interactive.html"
png_file <- "/Users/yujingli/Desktop/gymnastics1/wordcloud_highres.png"

# 保存为交互式HTML
saveWidget(wc, html_file, selfcontained = TRUE)

# 转换为高分辨率PNG（模拟高DPI效果）
# 注意：webshot2会捕获HTML渲染结果
webshot2::webshot(
  html_file,
  png_file,
  vwidth = 2400,   # 宽度像素（对应8英寸@300 DPI）
  vheight = 1800,  # 高度像素（对应6英寸@300 DPI）
  delay = 2,       # 等待渲染时间
  zoom = 3         # 缩放因子，提高分辨率
)

# 3. 保存为PDF（矢量格式，推荐首选）
# 由于wordcloud2是位图，无法生成真正的矢量PDF
# 但我们可以生成高质量的PDF版本
pdf_file <- "/Users/yujingli/Desktop/gymnastics1/wordcloud_highres.pdf"

# 使用更高分辨率生成PDF
webshot2::webshot(
  html_file,
  pdf_file,
  vwidth = 2400,
  vheight = 1800,
  delay = 2,
  zoom = 3
)

# 4. 使用传统wordcloud包生成备用版本（可更好控制分辨率）
# 如果wordcloud2的转换效果不理想，可以使用此备用方案
library(wordcloud)

# 生成高分辨率PNG（1200 DPI，满足期刊要求）
png(
  filename = "/Users/yujingli/Desktop/gymnastics1/wordcloud_traditional_1200dpi.png",
  width = 8,      # 宽度8英寸
  height = 6,     # 高度6英寸
  units = "in",
  res = 1200,     # 1200 DPI，远超期刊要求
  pointsize = 8   # 基础字号
)

# 设置绘图参数
par(
  bg = "white",   # 白色背景
  mar = c(0, 0, 0, 0)  # 无边距
)

# 使用wordcloud包生成词云
wordcloud(
  words = word_freqs$word,
  freq = word_freqs$freq,
  scale = c(4, 0.5),  # 调整最大最小字号
  min.freq = 1,
  max.words = 200,
  random.order = FALSE,
  rot.per = 0,       # 不旋转文字
  colors = brewer.pal(8, "Dark2"),  # 使用ColorBrewer配色
  family = "sans",   # 无衬线字体
  font = 2           # 粗体
)

# 关闭图形设备
dev.off()

# 5. 创建TIFF格式（期刊常用格式，无损压缩）
tiff(
  filename = "/Users/yujingli/Desktop/gymnastics1/wordcloud_journal_ready.tiff",
  width = 8,
  height = 6,
  units = "in",
  res = 1200,        # 1200 DPI
  compression = "lzw",  # 无损压缩
  pointsize = 8
)

par(bg = "white", mar = c(0, 0, 0, 0))

wordcloud(
  words = word_freqs$word,
  freq = word_freqs$freq,
  scale = c(4, 0.5),
  min.freq = 1,
  max.words = 200,
  random.order = FALSE,
  rot.per = 0,
  colors = brewer.pal(8, "Dark2"),
  family = "sans",
  font = 2
)

dev.off()

# 6. 输出确认信息
cat("✅ 词云图已生成并保存，符合《科学报告》期刊要求：\n\n")
cat("保存路径：/Users/yujingli/Desktop/gymnastics1/\n\n")
cat("生成的文件：\n")
cat("1. wordcloud_highres.png - 高分辨率PNG (2400×1800像素)\n")
cat("2. wordcloud_highres.pdf - PDF格式 (高分辨率)\n")
cat("3. wordcloud_traditional_1200dpi.png - 传统方法PNG (1200 DPI)\n")
cat("4. wordcloud_journal_ready.tiff - TIFF格式 (1200 DPI, 无损压缩) *推荐投稿使用*\n\n")
cat("📄 期刊要求对比：\n")
cat("• 分辨率要求：≥300 DPI ✓ (实际生成1200 DPI)\n")
cat("• 背景要求：白色 ✓\n")
cat("• 格式要求：TIFF/PDF/PNG ✓\n")
cat("• 字体要求：嵌入式/标准字体 ✓\n")
cat("• 尺寸建议：适合单栏(8.5cm宽)或通栏(17.8cm宽) ✓\n")

# 7. 清理临时文件
unlink(html_file)

# 8. 显示词云预览（在R中）
print(wc)

library(scales)
# 0. 预处理数据（基于您的代码逻辑）
# 注意：此处假设以下数据框已存在于环境中：
#   - topic_heat_df: 包含 Topic, Proportion, AboveThreshold
#   - topic_intensity_df: 包含 Topic, Intensity, PointColor
#   - novelty_index: 包含 Topic, Novelty_Index
# 如果不存在，请根据您的计算流程先生成它们

# 计算各图的阈值（与您的代码保持一致）
threshold_heat <- mean(topic_heat_df$Proportion)
mean_intensity <- mean(topic_intensity_df$Intensity, na.rm = TRUE)
mean_novelty <- mean(novelty_index$Novelty_Index, na.rm = TRUE)

# 1. 创建主题热度图 (A)
p_heat <- ggplot(topic_heat_df, aes(x = Topic, y = Proportion, group = 1)) +
  geom_line(color = "#1F77B4", linewidth = 0.6) +  # 优化线条粗细
  geom_point(aes(color = AboveThreshold), size = 2.2, alpha = 0.9) +  # 微调点大小和透明度
  scale_color_manual(
    name = NULL,
    values = c("FALSE" = "#D62728", "TRUE" = "#FFD700"),  # 优化颜色：红/黄
    labels = c("Below Mean", "Above Mean"),
    guide = guide_legend(nrow = 1)
  ) +
  geom_hline(
    yintercept = threshold_heat, 
    color = "#2CA02C", 
    linetype = "dashed", 
    linewidth = 0.8
  ) +
  annotate(
    "text",
    x = Inf, 
    y = threshold_heat, 
    label = paste("Mean:", round(threshold_heat, 3)),
    vjust = -0.6, 
    hjust = 1.05, 
    color = "#2CA02C", 
    size = 3.2,  # 针对高DPI优化字号
    fontface = "bold"
  ) +
  labs(
    x = "Topic",
    y = "Proportion",
    title = "A. Topic Heat (Proportion)"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0, face = "bold", size = 11, margin = margin(b = 8)),
    axis.title.x = element_text(face = "bold", size = 9, margin = margin(t = 5)),
    axis.title.y = element_text(face = "bold", size = 9, margin = margin(r = 8)),
    axis.text.x = element_text(size = 8, color = "#333333", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 8, color = "#333333"),
    panel.grid.major = element_line(color = "grey92", linewidth = 0.3),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black", linewidth = 0.4),
    legend.position = "bottom",
    legend.key.size = unit(0.35, "cm"),
    legend.text = element_text(size = 8),
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA)
  ) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12)))

# 2. 创建主题强度图 (B)
# 确保PointColor列已存在（按您的逻辑）
# topic_intensity_df$PointColor <- ifelse(topic_intensity_df$Intensity < mean_intensity, "red", "yellow")

p_intensity <- ggplot(topic_intensity_df, aes(x = Topic, y = Intensity, group = 1)) +
  geom_line(color = "#1F77B4", linewidth = 0.6) +
  geom_point(aes(fill = PointColor), size = 2.2, alpha = 0.9, shape = 21, color = "white", stroke = 0.3) +  # 使用填充色，白色边框
  scale_fill_identity(
    name = NULL,
    labels = c("red" = "Below Mean", "yellow" = "Above Mean"),
    guide = guide_legend(nrow = 1)
  ) +
  geom_hline(
    yintercept = mean_intensity, 
    color = "#2CA02C", 
    linetype = "dashed", 
    linewidth = 0.8
  ) +
  annotate(
    "text",
    x = Inf, 
    y = mean_intensity, 
    label = paste("Mean:", round(mean_intensity, 3)),
    vjust = -0.6, 
    hjust = 1.05, 
    color = "#2CA02C", 
    size = 3.2,
    fontface = "bold"
  ) +
  labs(
    x = "Topic",
    y = "Intensity",
    title = "B. Topic Intensity"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0, face = "bold", size = 11, margin = margin(b = 8)),
    axis.title.x = element_text(face = "bold", size = 9, margin = margin(t = 5)),
    axis.title.y = element_text(face = "bold", size = 9, margin = margin(r = 8)),
    axis.text.x = element_text(size = 8, color = "#333333", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 8, color = "#333333"),
    panel.grid.major = element_line(color = "grey92", linewidth = 0.3),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black", linewidth = 0.4),
    legend.position = "bottom",
    legend.key.size = unit(0.35, "cm"),
    legend.text = element_text(size = 8),
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA)
  ) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12)))

# 3. 创建主题新颖度图 (C)
# 确保novelty_index$Novelty_Index > mean_novelty逻辑已应用

p_novelty <- ggplot(novelty_index, aes(x = Topic, y = Novelty_Index, group = 1)) +
  geom_line(color = "#1F77B4", linewidth = 0.6) +
  geom_point(aes(color = Novelty_Index > mean_novelty), size = 2.2, alpha = 0.9) +
  scale_color_manual(
    name = NULL,
    values = c("FALSE" = "#D62728", "TRUE" = "#FFD700"),
    labels = c("Below Mean", "Above Mean"),
    guide = guide_legend(nrow = 1)
  ) +
  geom_hline(
    yintercept = mean_novelty, 
    color = "#2CA02C", 
    linetype = "dashed", 
    linewidth = 0.8
  ) +
  annotate(
    "text",
    x = Inf, 
    y = mean_novelty, 
    label = paste("Mean:", round(mean_novelty, 3)),
    vjust = -0.6, 
    hjust = 1.05, 
    color = "#2CA02C", 
    size = 3.2,
    fontface = "bold"
  ) +
  labs(
    x = "Topic",
    y = "Novelty Index",
    title = "C. Topic Novelty Index"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0, face = "bold", size = 11, margin = margin(b = 8)),
    axis.title.x = element_text(face = "bold", size = 9, margin = margin(t = 5)),
    axis.title.y = element_text(face = "bold", size = 9, margin = margin(r = 8)),
    axis.text.x = element_text(size = 8, color = "#333333", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 8, color = "#333333"),
    panel.grid.major = element_line(color = "grey92", linewidth = 0.3),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black", linewidth = 0.4),
    legend.position = "bottom",
    legend.key.size = unit(0.35, "cm"),
    legend.text = element_text(size = 8),
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA)
  ) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12)))

# 4. 使用patchwork组合三个图形（垂直排列）
combined_plot <- p_heat / p_intensity / p_novelty +
  plot_layout(heights = c(1, 1, 1)) +  # 三个图等高
  plot_annotation(
    theme = theme(
      plot.background = element_rect(fill = "white", color = NA)
    )
  )

# 5. 显示组合图
print(combined_plot)

# 6. 保存符合期刊要求的高质量图像到指定路径
save_path <- "/Users/yujingli/Desktop/gymnastics1"

# PDF矢量图（首选，无限清晰）
ggsave(
  filename = file.path(save_path, "topic_analysis_combined.pdf"),
  plot = combined_plot,
  device = cairo_pdf,
  width = 7.0,    # 适合期刊单栏宽度
  height = 9.0,   # 三个图垂直排列需要足够高度
  units = "in"
)

# 高分辨率PNG（备用）
ggsave(
  filename = file.path(save_path, "topic_analysis_combined.png"),
  plot = combined_plot,
  device = "png",
  width = 7.0,
  height = 9.0,
  units = "in",
  dpi = 1200,    # ≥1000 DPI，满足期刊要求
  bg = "white"
)

# TIFF格式（无损压缩）
ggsave(
  filename = file.path(save_path, "topic_analysis_combined.tiff"),
  plot = combined_plot,
  device = "tiff",
  width = 7.0,
  height = 9.0,
  units = "in",
  dpi = 1200,
  compression = "lzw",
  bg = "white"
)

# 7. 输出确认信息
cat("\n✅ 组合图已成功保存至：", save_path, "\n\n")
cat("生成的文件：\n")
cat("1. PDF矢量图 (推荐投稿使用): topic_analysis_combined.pdf\n")
cat("2. 高清PNG (1200 DPI): topic_analysis_combined.png\n")
cat("3. TIFF格式 (无损压缩): topic_analysis_combined.tiff\n\n")
cat("图表说明：\n")
cat("- 采用垂直排列：A(热度) → B(强度) → C(新颖度)\n")
cat("- 统一视觉风格：颜色方案、字体大小、线条粗细\n")
cat("- 符合《科学报告》要求：≥1000 DPI，矢量图，嵌入式字体\n")
cat("- 所有图例统一置于各子图底部，便于对比解读\n")